<?php
error_reporting(0);
defined('BASEPATH') OR exit('No direct script access allowed');

class Destination extends CI_Controller {

    function __construct()
    {
        parent::__construct();
        $this->load->model('Model_user');
    }

    public function index()
    {
        $data = array();
        if (isset($_POST['submit'])) {
            if ($_POST['preid']) {
                //echo $_POST['as'];die;
                $data['id'] = $_POST['preid'];
                $data['name'] = $_POST['name'];
                $data['location'] = $_POST['location'];
                $data['created'] = date('Y-m-d H:i:s');
                $data['status'] = $_POST['as'];
                if ($_FILES['file']['tmp_name']) {
                    move_uploaded_file($_FILES['file']['tmp_name'], 'assets/images/' . $_FILES['file']['name']);
                    $data['image'] = $_FILES['file']['name'];
                } else {
                    $data['image'] = $_POST['preimage'];
                }
                if ($this->Model_user->update($data['id'], $data) == TRUE) {
                    $data['success_message'] = 'Successfully updated !';
                } else{
                    $data['success_message'] = 'Error occured !';
                }

            } else {
               // echo $_POST['as'];die;
                $data['name'] = $_POST['name'];
                $data['location'] = $_POST['location'];
                $data['created'] = date('Y-m-d H:i:s');
                $data['status'] = $_POST['as'];

                if ($_FILES['file']['tmp_name']) {
                    move_uploaded_file($_FILES['file']['tmp_name'], 'assets/images/' . $_FILES['file']['name']);
                    $data['image'] = $_FILES['file']['name'];
                }


                if ($this->Model_user->save($data) == TRUE) {
                    $data['success_message'] = 'Successfully created !';
                } else {
                    $data['error_message'] = 'error created !';
                }
            }
        }
        $this->load->view('form_page',$data);
    }
    public function edit()
    {
        $id = $this->uri->segment(2);
        if (!empty($id)) {
            $t_user = $this->Model_user->getById($id);
            $data['data'] = $t_user;
            $this->load->view('form_page',$data);

           // print_r($t_user);
//            if ($t_user != FALSE) {
//                $this->Model_user->delete($id);
//            }
        }
    }

}
?>