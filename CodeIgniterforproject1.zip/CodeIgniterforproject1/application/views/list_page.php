<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?><!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <title>Welcome</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">
</head>

<body class="container">
<nav class="navbar navbar-inverse">
    <div class="container-fluid">
        <div class="navbar-header">
            <a class="navbar-brand" href="<?= base_url();?>">PROJECT</a>
        </div>
        <ul class="nav navbar-nav">
            <li class="active"><a href="<?= base_url();?>">Form</a></li>
            <li><a href="/CodeIgniterforproject/home">Home</a></li>
            <li><a href="/CodeIgniterforproject/list">List</a></li>
        </ul>
    </div>
</nav>
<h3>THESE ARE ALL THE LIST IN DB .ENJOY !!!</h3><hr>

<hr/>
<table class="table table-striped table-hovered">
    <thead>
    <tr>
        <th>ID</th>
        <th>Name</th>
        <th>Location</th>
        <th>Status</th>
        <th>Created</th>
        <th>Image</th>
    </tr>
    </thead>
    <tbody>
    <?php
    $i = 1;
    foreach($details as $here) {
        ?>
        <tr>
            <td><?php echo $i++; ?></td>
            <td><?php echo $here['name']; ?></td>
            <td><?php echo $here['location']; ?></td>
            <td><?php echo $here['status']; ?></td>
            <td><?php echo $here['created']; ?></td>
            <td><img src="<?php echo "assets/images/".$here['image']; ?>" alt="nice_view" width="325" height="200"></td>
            <td>
                <a href="<?php echo base_url().'user-edit/'.$here['id']; ?>" class="btn btn-sm btn-info">Edit</a>
                <a href="<?php echo base_url().'user-delete/'.$here['id']; ?>" class="btn btn-sm btn-danger">Delete</a>
            </td>
        </tr>
        <?php
    }
    ?>

    <?php if ($this->session->flashdata('message') != '') { ?>
        <div class="alert alert-success"><?php echo $this->session->flashdata('message'); ?></div>
    <?php } ?>
</body>
</html>