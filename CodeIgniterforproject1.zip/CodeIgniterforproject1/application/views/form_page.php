<?php
        //error_reporting(0);
defined('BASEPATH') OR exit('No direct script access allowed');
?><!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <title>Welcome</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">
</head>
<body class="container">
<nav class="navbar navbar-inverse">
    <div class="container-fluid">
        <div class="navbar-header">
            <a class="navbar-brand" href="<?= base_url();?>">Project</a>
        </div>
        <ul class="nav navbar-nav">
            <li class="active"><a href="<?= base_url();?>">Form</a></li>
            <li><a href="/CodeIgniterforproject/home">Home</a></li>
            <li><a href="/CodeIgniterforproject/list">List</a></li>
        </ul>
    </div>
</nav>
    <h3>WELCOME TO FORM PAGE </h3><HR>


    <?php if (isset($success_message)) { ?>
        <div class="alert alert-success"><?php echo $success_message; ?></div>
    <?php } ?>
    <?php if (isset($error_message)) { ?>
        <div class="alert alert-danger"><?php echo $error_message; ?></div>
    <?php } ?>
    <form method="POST" action="<?php echo base_url(); ?>" enctype="multipart/form-data">
        <div class="container">
            <div class="form-group">
                <label for="name">Name</label>

                <input type="text" class="form-control" name="name" placeholder="Name of Destination " <?php if($data){ ?>value="<?= $data['name'] ?>" <?php } ?> >

            </div>
            <div class="form-group">
                <label for="location">Location</label>
                <input type="text" class="form-control" name="location" placeholder="Location of Destination" <?php if($data){ ?>value="<?= $data['location'] ?>" <?php } ?> >
            </div>

            <div class="form-group">
                <label>Status:</label>
                <?php if($data) { ?>
                <?php if($data['status']==1) {?> <input type="checkbox" name="as" value="1" checked /> <?php } ?>
                <?php if($data['status']==0) {?> <input type="hidden" name="as" value="0" /> <input type="checkbox" name="as" value="1" /> <?php } } else {?>
                    <input type="hidden" name="as" value="0" />
                    <input type="checkbox" name="as" value="1" />

<?php }?>

            </div>
            <div class="form-group">
                <label for="url">URL</label>
<!--                <input type="text" name="url" class="form-control" id="image" placeholder="URL of Destination"><br>-->
<!--                <button type="submit" class="btn btn-primary" name="submit">Submit</button>-->
<!--               yeseri input,password,submit lai ni form_input ,form_ouput garera garna sakinxa-->
                <input type="hidden" value="<?= $data['image'] ?>" name="preimage" />
                <input type="hidden" value="<?= $data['id'] ?>" name="preid" />
                <input type="file" name="file" class="form-control">
                <?php
                echo form_reset(['name'=>'reset','value'=>'Reset','class'=>'btn btn-default']);
                ?>
                <?php
                echo form_submit(['name'=>'submit','value'=>'Submit','class'=>'btn btn-primary']);

                ?>
    </form>
<!--
            </div>

    </form>
</body>
</html>