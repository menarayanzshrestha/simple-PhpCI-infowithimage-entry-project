<?php

class Home extends CI_Controller {

    function __construct()
    {
        parent::__construct();
        $this->load->model('Model_user');

    }

    public function index()
    {

        $data = array();
        $data['details'] = $this->Model_user->getOne();
        $this->load->view('home_page', $data);
    }

}
?>