<?php

class List_Controller extends CI_Controller {

    function __construct()
    {
        parent::__construct();
        $this->load->model('Model_user');

    }

    public function index()
    {

//
        $data = array();
//        $id = $this->uri->segment(2);
//        if (!empty($id)) {
//            $t_user = $this->Model_user->getById($id);
//            if ($t_user != FALSE) {
//                $this_user = $t_user;
//            }
//        }

        $data['details'] = $this->Model_user->getAll();

        $this->load->view('list_page', $data);


    }

    /**
     *
     */
    public function user_delete()
    {
        $id = $this->uri->segment(2);
        if($this->Model_user->delete($id)){
        echo 'deleted';
        }else
            echo 'nothing';
    }

}

?>