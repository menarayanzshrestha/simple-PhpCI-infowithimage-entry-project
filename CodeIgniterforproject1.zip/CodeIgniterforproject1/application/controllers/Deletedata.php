<?php

class Deletedata extends CI_Controller {

    function __construct()
    {
        parent::__construct();
        $this->load->model('Model_user');

    }

    public function index()
    {
        $id = $this->uri->segment(2);
        if($this->Model_user->delete($id)){
            $this->session->set_flashdata('message', 'Successfully Deleted !');
            redirect(base_url().'list');
        }
    }
}
?>